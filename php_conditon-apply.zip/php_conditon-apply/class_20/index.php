
<a href="https://www.youtube.com/watch?v=zNzUVRD6ev8&ab_channel=WebShip">class-21 php tutorial</a>
<?php

$user = " ";

$age  = 40;
/*
if ( $age > 18 ) {
    $user = "Young / Old / Admin"; 
}
else {
    $user = "Child / Guest";
} 

echo $user;
*/
$result_1 = 600  ;

$result_2 = 500 ;

//$user = ( condition ) ? Result : Result-2;
$user = ( $age > 18 ) ? "$result_1" : "$result_2";
echo $user;
?>