
<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>PHP Class-26 tutorial</title>
      <a href="https://www.youtube.com/watch?v=gI4CYpihIZU&ab_channel=WebShip">php tutorial 26</a>
</head>
<body>

      
      <form action="#">
            Year 
            <select name="" id="">     
                  <?php
                  /*
                        $year = 1971;
                        while ($year <= 2071) {                 
                  ?>
                  <option value="<?php echo $year; ?>"><?php echo $year;?></option>
                  <?php
                        $year++;
                  } */
                  ?>

                  <?php
                       $year = 1971;
                       while ($year <= 2022) {
                              echo "<option value='$year'>$year</option>";
                        $year++;
                       }
                  ?>
                  
            </select>
            
      </form>

      <!----------

     
      <form action="#">
             Year 
            <select name="" id="">
                  <option value="2000">2000</option>
                  <option value="2001">2001</option>
                  <option value="2002">2002</option>
                  <option value="2003">2003</option>
            </select>

      </form>
      <!----------->

</body>
</html>
<?php

$count = 1;

while ( $count <= 15 ) {
      echo "$count odd Number<br>";
      $count += 2;
}

/*
$count = 0;

while ( $count <= 10 ) {
      echo "$count Hello Srabon Kaku !!<br>";
      $count ++;
}
*/

/*
$count = -5;

while ( $count <= 10 ) {
      echo "$count Hello Srabon Kaku !!<br>";
      $count ++;
}
*/
?>