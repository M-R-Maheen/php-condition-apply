
<a href="https://www.youtube.com/watch?v=z9HiC1-7AXk&ab_channel=WebShip">class-18 php tutorial</a>
<?php

$first_num = 12;

$second_num = 12;

var_dump($first_num <=> $second_num);
?>