<a href="https://www.youtube.com/watch?v=GHtPIEjT6Wg">class-15 php tutorial</a>
<br>
<?php 
$amount = 10;

echo ++$amount;//[pre-fix] //$amount = $amount + 1; // $amount+= 1;

echo "<br>";

echo $amount;

/*
$amount = 10;

echo $amount++;//[post-fix]//$amount = $amount + 1; // $amount+= 1;

echo "<br>";

echo $amount;
*/

?>

<?php 
/*
$amount = 10;

//$amount++; // $amount + 1; // $amount+= 1;[Increment]

$amount--; // $amount - 1; // $amount-= 1;[Decrement]

echo $amount;
*/
/*
$amount = 10;

$amount++; //Post-fix
++$amount; //Pre-fix

echo $amount;
*/
?>