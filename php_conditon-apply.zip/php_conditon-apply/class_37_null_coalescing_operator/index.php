
<a href="https://www.youtube.com/watch?v=W4E24DtIfvk&ab_channel=WebShip">class_17<br> <br> <br> </a>
<?php 

// $my_name = "Mamunur Roshid";

/* if(!isset($my_name)) {
      $my_name = "Mamunur";
}

echo $my_name ;
*/
?>

<?php     // ternary operator

$name_val = isset($my_name) ? $my_name : "Mahi <br><br><br>"; 

echo $name_val;

?>

<?php    // Null Coalescing Operator

$name_val = $my_name ?? " Mahi";

echo $name_val;

?>