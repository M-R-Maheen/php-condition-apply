
<a href="https://www.youtube.com/watch?v=KMHTZjgeg9I&ab_channel=WebShip">class-17 php tutorial</a>

<?php
$var_1 = 23;
$var_2 = 20;

var_dump($var_1 != $var_2);

/*
$var_1 = 22;
$var_2 = 20;

> --- $var_1 > $var_2 -- false//less-then

< --- $var_1 < $var_2 -- //geater-then

>= --- $var_1 >= $var_2 --// geater-then 

<= --- $var_1 <= $var_2 -- //less-then + equal-to

== --- $var_1 == $var_2 -- false//(==) equal-to 

!= --- $var_1 != $var_2 -- true // not equal

<> --- $var_1 <> $var_2 -- true // not equal

=== --- $var_1 === $var_2 -- //TRIPLE EQUAL TO

!== --- $var_1 !== $var_2 --//not exact to
*/
?>

<?php
/*
$first_var = 22;
$second_var = 20;

>= --- $first_var >= $second_var -- true ;//$first_var not big but equql SO = ans:TRUE 
// >= --- 20 >= 20 -- true
*/

/*
$first_var = 20;
$second_var = 20;

>= --- $first_var >= $second_var -- true ;//$first_var not big but equql SO = ans:TRUE 
// >= --- 20 >= 20 -- true
*/
?>


<?php
/*
$first_var = 10;
$second_var = 20;

> --- $first_var > $second_var -- false//$first_var not SO = ans:FALSE
// > --- 10 > 20 -- false

< --- $first_var < $second_var -- true//$first_var is small SO = ans:TRUE 
// < --- 10 < 20 -- true

>= --- $first_var >= $second_var -- false//>= 10 OR $first_var is small SO = ans:FALSE 
// >= --- 10 >= 20 -- false
*/
?>