<?php 
/*==============================
product calculation start
==============================*/

$first_price = 3333;

$second_price = 6666;


$total_price = $first_price + $second_price ; //Additional price

$subtraction_price = $second_price - $first_price ; #subtraction price

$mass_price = $first_price * $second_price ; //mass price




?>
<?php

echo "Your Additional or Total Price Is : $total_price ";
echo "Your subtraction or rest of the price Is : $subtraction_price ";
echo "Your Mass price is : $mass_price ";

/*==============================
product calculation end
==============================*/
?>

<?php
/*======================================
  Subject ways result calculation start
======================================*/
$bangla = 80;
$english = 89;
$general_math = 90;
$social_science = 90;
$geography = 80;
$history = 87;
$economic = 70;

$total_subject_result = $bangla + $english + $general_math + $social_science + $geography + $history + $economic;
$subject_average = 586 % 7;


echo "Your Total subjectt result is : $total_subject_result";
echo "<br>";
echo "Your average result is: $subject_average ";


/*====================================
  Subject ways result calculation end
=====================================*/
?>