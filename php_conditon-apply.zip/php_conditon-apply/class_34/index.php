<?php
$first_name = "Mamunur";

$last_name = "Roshid";


$new_str = sprintf ("Your First name is:%s And Your last name is: %s", $first_name, $last_name ."<br>"."<br>");

echo "New  string------ " . $new_str;

?>
<?php
/*
$first_name = "Mamunur";

$last_name = "Roshid";

$full_name = " Mamunur Roshid";

printf ('Your First name is:%2$s And <br><br> Your last name is: %1$s', $first_name ."<br>"."<br>", $last_name ."<br>"."<br>");

printf ('Your First name is:%s And Your last name is: %s', $first_name, $last_name ."<br>"."<br>");

printf ("Your Full Name Is:%s", $full_name);
*/
?>