<?php

for ($count = 1; $count <= 10; $count ++)  {

     echo "PHP<br>";
     if ($count == 6) {
         continue;

     }
         echo "is<br>";
         echo "awesome <br><br><br>";
  
}

/*
for ($count = 1; $count <= 10; $count ++)  {

      echo "PHP<br>";
      if ($count != 6) {
          echo "is<br>";
          echo "awesome <br><br><br>";
   }
 }*/
?>