
<a href="https://www.youtube.com/watch?v=Go6w1rzXPQU">class-13 php tutorial</a>
<?php 
$first_num = 5;

$second_num = 4;

$num = $first_num ** $second_num ;// exponenciation

//$num = $first_num % $second_num ;//modulas 5%4=1

//$num = $first_num / $second_num ;//divided 5/4=1.25
//$num = $first_num * $second_num ;//into 5*4= 20
//$num = $first_num - $second_num ;//subsection 5-4 =1 
//$num = $first_num + $second_num ;//addition 5+4 =9

echo ($num);

/*
$num = 13 + 15;

//echo "Addition:($num)"; /// Addition  //////

var_dump ($num);  ///charectar check  ///////
*/
?>