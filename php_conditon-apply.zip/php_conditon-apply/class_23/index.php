<?php

$amount = 100;

if ( ($amount >= 1500) && ( $amount <= 2000) )  {
            echo "$amount is very high cause of This amount is between 1500 to 2000";
}
else if ( ($amount >= 1200) && ( $amount <= 1499) ) {
      echo "$amount is medium cause of this amount is between 1200 to 1500";
}
else {
      echo "This amount is so high";
}
?>

<?php
/*
$user_name = "Sanny";

$password  = "123456";

if ( ($user_name == "Sanny") && ($password == "123456") ) {
      echo "Login successfully";
}
*/
?>