<?php
$name = "Mamun";


switch (true ) {
    case ($name == "Sumon") :         
        echo "Sumon Is a Good Boy";
            break ;
    case ($name == "Sumi is a good Girl") :        
        echo "Sumi";
            break ;
    case ($name == "Mamun") :
        echo "Mamun is a  web developer";
        break ;
    
    case 0:
        echo "Zero";
            break ;

    default:
        echo "Data Not Matched !<br> Please Try Again !!!";
}

?>

<?php
/*
$num = "3PHP";

switch ( $num ) {
    case 1:         //case "1" string
        echo "One";
            break ;
    case 2:         // case(string)1: type casting
        echo "Two";
            break ;
    case 3:
        echo "Three";
        break ;
    
    case 0:
        echo "Zero";
            break ;

    default:
        echo "Data Not Matched !<br> Please Try Again !!!";
}
*/
?>

<?php
/*
$name = "Srabon";

switch ( $name ) {
    case "Srabon":
    case "mamunur":  // ||,OR  (alternative use)
        echo "Hello $name .<br>";
            break ;
    case "mamun";
        echo " Hello $name .<br>";
            break ;
    default:
        echo "Bye";
}
*/
?>