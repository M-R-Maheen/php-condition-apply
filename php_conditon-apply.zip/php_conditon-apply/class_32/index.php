<?php

echo "Mamunur <br>";
goto web_ship;
echo "Roshid<br>";


web_ship:
echo "web ship class Tutorial 10<br>";

?>

<?php

/*
for ($outer_list = 1; $outer_list <= 3; $outer_list++) {
    echo "List $outer_list<br>";

    for ($inner_list = 1; $inner_list <= 2; $inner_list++) {
        echo "----------Inner list $inner_list<br>";

        if ($outer_list == 2 && $inner_list == 1) {
            goto Out;
        }
    }  
}
Out:
echo "End<br><br><br>"; */

?>

<?php
/*

for ($outer_list = 1; $outer_list <= 5; $outer_list++) {
    echo "List $outer_list<br>";

    for ($inner_list = 1; $inner_list <= 10; $inner_list++) {
        echo "----------Inner list $inner_list<br>";

        if ($outer_list == 2 && $inner_list == 1) {
            break 2;
        }
    }  
}
echo "end";
*/
?>