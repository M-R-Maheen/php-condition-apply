<a href="https://www.youtube.com/watch?v=5w-zCsU2s4A&ab_channel=WebShip">PHP class 31 tutorial</a>
<?php

for ($outer_list = 1; $outer_list <= 5; $outer_list++) {
    echo "Class_Ten $outer_list<br>";

    for ($inner_list = 1; $inner_list <= 10; $inner_list++) {
        echo "----------Inner list $inner_list<br>";

    }       
        for ($inner_list = 1; $inner_list <= 10; $inner_list++) {
            echo "------------------Inner list $inner_list<br>";

        }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>php tutorial class-31</title>
</head>
<body>

<?php

for ($outer_list = 1; $outer_list <= 5; $outer_list++) {
    echo "Outer list $outer_list<br>";

    for ($inner_list = 1; $inner_list <= 5; $inner_list++) {
        echo "----------------Inner list $inner_list<br>";

    }
}


?>
    <!--------------------
        list start
    --------------------->
    <ul>
        <li>list-1
        <ul>
                <li>inner-1</li>
                <li>inner-2</li>
            </ul>
        </li>
            
        <li>list-2
        <ul>
                <li>inner-1</li>
                <li>inner-2</li>
            </ul>
        </li>
           
        <li>list-3
            <ul>
                <li>inner-1</li>
                <li>inner-2</li>
            </ul>
        </li>
    </ul>
     <!--------------------
        list end
    --------------------->

</body>
</html>