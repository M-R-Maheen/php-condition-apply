<?php 
echo"<h2>Alternative Syntex If & Else Use...</h2><br><br>";
?>

<?php if (false) : ?>
      <h1>Hello 1</h1>
<?php elseif (false) : ?>
      <h1>Hello 2</h1>

<?php elseif (true) : ?>
      <h1>Hello 3</h1>
<?php else :  ?>
      echo "Bye";
<?php endif ;?>

<?php 
echo"<h2>For Loop Use</h2><br><br>";

?>
<?php for ($count = 1; $count <= 10; $count++) : ?>

<h1>Hello <?php echo $count ?></h1>

<?php endfor; ?>


<?php

switch (2):
      case 1 :
            echo "Hello switch case argument";
            echo "Hello";
            break ;
      case 2 :
            echo "<h2>Switch case argument</h2>";
            echo " <h3>Hello,,,,!! Mamunur Roshid</h3>";
            break ;
      default:
      echo "Bye";

endswitch;

?>



<?php
/*
if ( ) {

} else {

}

for ( ) {

}

switch () {

}
       
*/
?>