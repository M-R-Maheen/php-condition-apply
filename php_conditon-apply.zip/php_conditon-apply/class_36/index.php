<?php
 
$val1 = 12;

//var_dump(isset($val1));

if (isset($val1)) {
$result = $val1 + 5;

echo $result ;
}
?>



<?php 

$my_name = "Mamunur Roshid";

if(!isset($my_name)) {
      $my_name = "Mamunur";
}

echo $my_name ;

?>

