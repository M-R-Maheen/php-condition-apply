<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>php</title>
</head>
<body>

    <?php
    $first_name = "Mamunur";
    $amount = 1990 ;
    ?>
    <h1>Hello <?php echo $first_name ?>,Your Amount is: <?php echo $amount ?></h1>
    <h2>Total amout is: <?php echo $amount?></h2>
    <h1>Your name is: <?php echo $first_name ?></h1>


</body>
</html><?php

$first_name = "Mamunur";

$name = "first_name";

echo $$name;




?>
