<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Class 04 </title>
</head>
<body>
    <h1> Hello PHP </h1>

    
    <?php  
        echo "Hello Srabon" 
    ?>
    <h1><?php
         echo "Welcome to php "; ?>PHP</h1>

    
    <?php 
   
        echo "Mamunur Roshid Maheen 
            <br> Mobile No. 0170758448";
    ?>
    <br>
    <h1>
    <?php
        echo "Sanzid Ahmed ";
        echo "Srabon";
    
    
    ?> 
    </h1>


    <form action="index.php" method="post">
        <input type="text" name="employee">
        <input type="submit">
    </form>
    <?php
        $salary = array("Mamun"=>"10000 tk", "Anila"=>"20000 tk", "Srabon"=>"25000 tk","Ashik"=>"30000 tk",)
        echo $salary[$_POST["employee"]];


   ?>
</body>
</html>
