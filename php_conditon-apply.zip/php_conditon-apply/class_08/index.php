<a href="https://www.youtube.com/watch?v=1_TqGAfPQRM">PHP class-09 tutorial</a>
<?php 


$name = "Hassan"; // String type data store
$amount = 23;      // Integer type data
$amount = 22.23;  // Floating type data
$user_status = true; // Bulian type data
$user_status = false; // bulian type data
$name = "  ";    // null  type / empty type data
$name = null;  // null type data


echo "Data Type class-08 PHP" . "<br>". "<br>". "<br>";

echo "Re-asigned data" . "<br>". "<br>". "<br>";


?>

<?php 

$amount = 100;

$name = 0; // Integer Re-asigned (0 USE)

$name = null; // Integer Re-asigned (NULL use)



?>

<?php


$first_name = "Evan";

$first_name = null; // Re-asign string type data

echo $first_name;

?>