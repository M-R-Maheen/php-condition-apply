<?php

for ($count = 1; $count <= 10; $count ++)  {

      echo "Hello" . $count . "<br>";
      if ($count == 5) {
            break;
      }
}


?>