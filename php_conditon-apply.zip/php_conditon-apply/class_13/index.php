<a href="https://www.youtube.com/watch?v=teEC_a32RHk">class-14 PHP tutorial</a>
<br>
<a href="https://www.youtube.com/watch?v=IHVzseHh3Bo">Git & Git Hub Details in anisul Huq</a>
<?php 

$amount = 33;

$amount = $amount + 10; //Addition Operator

$amount += 10; // Addition Operator

$amount -= 10; // Subtration Operator

$amount *= 10; // Multi-plan Operator

$amount /= 10; // Divided Operator

$amount %= 10; // Modulas Operator

echo $amount;



?>