
<a href="https://www.youtube.com/watch?v=rE2_yafJ9MU&ab_channel=WebShip">class-23 php tutorial</a>
<?php

$user_name = "shamim";

$user_role = "eitor";

if ($user_name == "shamim" || $user_role == "editor") {
      echo "Hello Dear User";
}
?>