<?php
 
$val1 = 12;

$result = $val1 + 5;

echo $result ;

?>