
<a href="https://www.youtube.com/watch?v=VVSSCWbXkIM&ab_channel=WebShip">php-tutorial 25 </a>
<?php
$username = "mann";

$user_length = strlen($username);

if ( ! ($user_length >= 5 && $user_length <= 7) )  {

      echo "Hello"."<br>". "InValid Username";
} else {
      echo "Valid Username";
}

?> 

<?php
/*
$username = "abcd";

if ( !($username == "abcd") )  {

      echo "Hello Valid";
}
*/
?>