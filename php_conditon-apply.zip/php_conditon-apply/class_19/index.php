<a href="https://www.youtube.com/watch?v=CU3WwmAFK_c&ab_channel=WebShip">class-20 php tutorial</a>
<?php
$month_name = "mar";

if ($month_name == "jan") {
    echo "january";
}
else if ($month_name == "feb" ) {

    echo "February";
} 
else if ($month_name == "mar" ) {

    echo "March";
} 
else if ($month_name == "apr" ) {

    echo "April";
} 
else if ($month_name == "may" ) {

    echo "May";
}   
else if ($month_name == "jun" ) {

    echo "June";
} 
else if ($month_name == "jul" ) {

    echo "July";
} 
else if ($month_name == "aug" ) {

    echo "August";
} 
else if ($month_name == "sep" ) {

    echo "September";
} 
else if ($month_name == "otc" ) {

    echo "October";
} 
else if ($month_name == "nov" ) {

    echo "November";
} 
else if ($month_name == "dec" ) {

    echo "December";
} 
else {
    echo "Not Find";
}
?>