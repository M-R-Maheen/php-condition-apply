
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Class 04</title>
</head>
<body>
    
<?php
    $first_name = "Raja";
	
    $last_name  = "Babu";
	
    $full_name = "Raja Babu";
	
    $present_salary = 10000;
	
    $prevous_salary = 7777;
	
    $total_amount = 17700;  
	
	$present_amount = 3000;
	
	$monthly_cost = 14700;
	
    $address = " Test area, Test District, 7778";
	
    $test = "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Laboriosam ducimus placeat quae voluptates blanditiis impedit, quia laborum officia aut temporibus dolore! Molestias eos, voluptates blanditiis numquam ut facilis quaerat quisquam?";
	
    $myVariable = "Camel case";	
    $MyVariableTwo = "Title case";
    $my_variable_three = "Under score";
    
?>

<?php


    echo "Hello $full_name, Your Present salary is : $present_salary /=";
	echo "<br>";
    echo "Your prevous_salary is : $prevous_salary /=";
	echo "<br>";
    echo "Your Total amount is : $total_amount /=";
	echo "<br>";
	echo "Your monthly cost is : $monthly_cost /= ";
	echo "<br>";
	echo " Your present amount is: $present_amount";
    
?>

</body>
</html>


