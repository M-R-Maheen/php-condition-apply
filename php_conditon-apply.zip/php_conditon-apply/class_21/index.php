<a href="https://www.youtube.com/watch?v=4XzaxX6hE6g&ab_channel=WebShip">class- 22 tutorial php_uname</a>

<?php

$user = "Adil";

$is_admin = ($user == "Adil") ? true : false ;

var_dump( $is_admin );

?>