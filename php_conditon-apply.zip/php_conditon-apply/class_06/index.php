
<a href="https://www.youtube.com/watch?v=VILuoe4dcnw"> PHP Tutorial -07</a>
<?php

define("NAME", "Mamunur Roshid");

define("NICK_NAME", "Maheen");
define("FIRST_NAME", "Mamunur");
define ("AMOUNT", 300);

$amount = 2000;
$total_bill = 600;


echo NAME;
echo "<br>";
echo AMOUNT . "<br>" . "<br>" . "<br>";

?>

<?php

echo NAME;
echo "<br>";
echo "Your nick name is: " . NICK_NAME . "<br>"; # constant concatination
echo "Your Amount is: " . $amount . "<br>" . "<br>" . "<br>"; //veriable concatination

echo "Your First Name is : " . constant ("FIRST_NAME") . "<br>";

echo "Your total bill is : $total_bill";


?>

<?php

define ("LNAME", "Srabon" );

$amount = 20;

$text = "constant";

echo "Your Name is : " . $text ("LNAME");


?>