<?php

$count = 1;

do {
    echo $count . "<br>";
    $count++;  
}while ($count <= 10);


?>