

<a href="https://www.youtube.com/watch?v=tfJyTlDjpNs">class-11 PHP tutorial </a>
<?php

$frist_name = "sanzid";

$last_name = "ahmed";

$amount = 400;

$html_block = "<div> 
        <h1>%s</h1>
        <h2>%s</h2>
        <h1>%d</h1>

</div>";

printf ($html_block, ucwords($frist_name), ucwords($last_name), $amount ); 

 /*--------------------------------
            ucwords concatinate
    ---------------------------------*/
 /*
$frist_name = "sanzid";

$last_name = "ahmed";

$html_block = "<div> 
            <h1>". ucwords ($frist_name)."</h1>
            <h2>".ucwords ($last_name)."</h2>
</div>";

echo $html_block; */

/*
$html_block = "<div> 
            <h1>khondokar</h1>
            <h2>hassan</h2>
</div>";

echo $html_block; */

?>

<?php
/*
 $name = "mamunur roshid maheen...!!";

 $school_name = "darusha-1";

 $address = "test address";

 $update_name = ucwords ($name); //// first latter capitalize

 echo "Hello $update_name"; //// first latter capitalize

 echo "Hello ucwords $update_name"; //// ucwords not working

 echo "Hello" . ucwords ($update_name); ////concatination use
 echo "<br>";
 printf ("Hello %s Your School Name Is: %s  your address is: %s", ucwords($name), ucwords($school_name), ucwords("hi dear")); //

*/
?>