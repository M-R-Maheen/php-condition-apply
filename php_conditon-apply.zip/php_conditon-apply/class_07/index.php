
<a href="https://www.youtube.com/watch?v=ek15sBTquKo">class-08 PHP Tutorial</a>
<?php

$test = print ("Hello");  // value 1 atomatic 
echo $test;

?>

<?php 

echo "<h1> Mamunur </h1>";

?>

<?php 

$name = "Mamunur";


echo "<h1>".$name."</h1>";
echo "<h1> $name </h1>";

print "<h1> $name </h1>";
?>