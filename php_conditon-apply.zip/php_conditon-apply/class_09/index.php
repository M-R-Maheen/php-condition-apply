
<a href="https://www.youtube.com/watch?v=cS3jK0wzHc0">PHP class-10 tutorial</a>
<?php

$name = "Evan Alam";

$amount = 2000;

$is_admin = true;

var_dump($name);

echo "<br>";
echo "<br>";

var_dump($amount);

echo "<br>";
echo "<br>";

var_dump($is_admin);
?>