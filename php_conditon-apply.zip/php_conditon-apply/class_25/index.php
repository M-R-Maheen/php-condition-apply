<?php

$username = "abcd";
$password = "1234";
/*
if ($username == "abc" && $password == 234 ) {
      echo "Hello user";
} else if ($username == "abc" && $password != 1234 ) {
      echo "Invalid Password";
} else if ($password == 1234  && $username != "abcd") {
      echo "Invalid Username";
} else {
      echo "Invalid username / password";
}
*/
    

if ($username == "abc") {
  if ($password == 123456) {
      echo "Hello User";  
  } else {
      echo "Invalid Password";
  }
}else {
      echo "Invalid Username";
}

/*
if ($username == "abcd" && $password == 123456) {
      echo "hello user";
} else {
      echo "Invalid username / password";
}
*/
?>