<?php




$first_name = "Mamunur";

$first_name  .= " Roshid";//$first_name = $first-name . " Roshid";

echo $first_name;

/*
$first_name = "Mamunur";

$last_name  = "Roshid";

//$full_name  = "Hello Dear ".$first_name." ". $last_name;

//$full_name  = "Hello Dear"."<br>".$first_name." ". $last_name;

echo $full_name;
*/
?>

<?php
/*
$first_name = "Mamunur";

$last_name  = "Roshid";

$full_name  = $first_name." ". $last_name; //Concatination 

echo $full_name;
*/
?>
