
<a href="https://www.youtube.com/watch?v=ghH5sMQpa1A&ab_channel=WebShip">class-19 php tutorial</a>
<?php

$user_name = "Mmunur";

if ($user_name == "Mamunur") {
    echo "Login Successfully";
}
else {
    echo "Login Failed";
}
?>