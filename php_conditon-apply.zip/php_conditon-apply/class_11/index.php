

<a href="https://www.youtube.com/watch?v=cFJN7jD_3-8">class-12 tutorial-php</a>
<?php

$name = "Mamunur Roshid";

printf("[%-'@12.10s]", $name);   // Left align


/*
$name = "mamunur";

printf("[%10s]", $name); //// Right align 
*/

/*
$amount = 9.95 * 100;   //// ACTUAL RESULT FOR (%.0f) use floating 

printf('Your Amount Is: %.0f', $amount);
*/

/*
$amount = 50.55;   //////// PROPER VALUE FOR RESULT ///////

printf('Your Amount Is: %.2f', $amount);
*/

/*
$amount = 500;   ////--- MULTIPUL VALUE FOR USE 1 AGUMERNT----//////

$blance = 10900;

printf('Your Amount is: %1$d Another Amount is: %1$d Your Current Blance Now: %d', $amount, $blance);
*/

/*
$test = 35;    //////// Rules: 2, USE DOUBLE COTETION 

$test_two = 71;

printf('Amount: %2$d Your Another Amount is: %1$d, $test, $test_two );
*/

/*
$test = 35;    /////// Rules: 1, USE DOUBLE COTETION 

$test_two = 71;

printf("Amount: %2\$d Your Another Amount is: %d", $test, $test_two );
*/

/*
$test = 71;

printf("Amount: %x", $test ); //hexa-decimal number for %x ...
*/

/*
$test = 10;

printf("Amount: %o", $test ); // Octen number for %O
*/


/*
$test = 10;

printf("Amount: %b", $test ); //---- %b =Bainary---
*/

/*
$test = 10;

printf("Amount: %c", $test ); // %c = charectar
*/

/*
$amount = 97;

printf("Amount: %f", $amount ); // floating for use..%f
*/



/*++++++++++++++++++++++++++++++++++++++++++
         Integer for use...... %d 
+++++++++++++++++++++++++++++++++++++++++++*/
/*
$amount = 500;

printf(" Sanzid Ahmed..!! Your Total Bill Is: %d", $amount);
*/
?>